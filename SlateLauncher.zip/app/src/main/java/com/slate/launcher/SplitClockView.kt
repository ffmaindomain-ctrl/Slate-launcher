package com.slate.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.BatteryManager
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

/**
 * Big thin day-name (e.g. "THU") cut by a horizontal band that holds
 * time, date and battery: "14:00   AUG 30   100%".
 */
class SplitClockView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val bigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val bounds = Rect()

    private var dayFormat = D.CLOCK_DAY_FORMAT
    private var use24h = D.CLOCK_24H
    private var showTime = D.CLOCK_SHOW_TIME
    private var showDate = D.CLOCK_SHOW_DATE
    private var showBattery = D.CLOCK_SHOW_BATTERY
    private var gapPos = D.CLOCK_GAP_POS / 100f
    private var gapScale = D.CLOCK_GAP_SIZE / 100f
    private var rowScale = D.CLOCK_ROW_WIDTH / 100f
    private var align = D.CLOCK_ALIGN
    private var shadow = D.CLOCK_SHADOW

    private var day = ""
    private var time = ""
    private var date = ""
    private var batteryLevel = -1
    private var registered = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.action == Intent.ACTION_BATTERY_CHANGED) updateBattery(i)
            refreshTexts()
        }
    }

    init {
        bigPaint.textSize = context.sp(D.CLOCK_SIZE.toFloat())
        bigPaint.letterSpacing = D.CLOCK_SPACING / 100f
        bigPaint.typeface = Fonts.make(D.CLOCK_FONT, 200)
        smallPaint.textSize = context.sp(D.CLOCK_SMALL_SIZE.toFloat())
        smallPaint.letterSpacing = D.CLOCK_SMALL_SPACING / 100f
        smallPaint.typeface = Fonts.make(D.CLOCK_FONT, 500)
        if (isInEditMode) batteryLevel = 100
        refreshTexts()
    }

    fun applyPrefs(p: Prefs) {
        dayFormat = p.str(K.CLOCK_DAY_FORMAT, D.CLOCK_DAY_FORMAT)
        use24h = p.bool(K.CLOCK_24H, D.CLOCK_24H)
        showTime = p.bool(K.CLOCK_SHOW_TIME, D.CLOCK_SHOW_TIME)
        showDate = p.bool(K.CLOCK_SHOW_DATE, D.CLOCK_SHOW_DATE)
        showBattery = p.bool(K.CLOCK_SHOW_BATTERY, D.CLOCK_SHOW_BATTERY)
        gapPos = p.int(K.CLOCK_GAP_POS, D.CLOCK_GAP_POS) / 100f
        gapScale = p.int(K.CLOCK_GAP_SIZE, D.CLOCK_GAP_SIZE) / 100f
        rowScale = p.int(K.CLOCK_ROW_WIDTH, D.CLOCK_ROW_WIDTH) / 100f
        align = p.str(K.CLOCK_ALIGN, D.CLOCK_ALIGN)
        shadow = p.bool(K.CLOCK_SHADOW, D.CLOCK_SHADOW)

        val font = p.str(K.CLOCK_FONT, D.CLOCK_FONT)
        val weight = p.str(K.CLOCK_WEIGHT, D.CLOCK_WEIGHT).toIntOrNull() ?: 200
        bigPaint.typeface = Fonts.make(font, weight)
        bigPaint.textSize = context.sp(p.int(K.CLOCK_SIZE, D.CLOCK_SIZE).toFloat())
        bigPaint.letterSpacing = p.int(K.CLOCK_SPACING, D.CLOCK_SPACING) / 100f
        bigPaint.color = p.color(K.CLOCK_COLOR, D.CLOCK_COLOR)
        val outline = p.str(K.CLOCK_STYLE, D.CLOCK_STYLE) == "outline"
        bigPaint.style = if (outline) Paint.Style.STROKE else Paint.Style.FILL
        bigPaint.strokeWidth = if (outline) context.dp(p.int(K.CLOCK_STROKE, D.CLOCK_STROKE).toFloat()) else 0f

        val smallWeight = p.str(K.CLOCK_SMALL_WEIGHT, D.CLOCK_SMALL_WEIGHT).toIntOrNull() ?: 500
        smallPaint.typeface = Fonts.make(font, smallWeight)
        smallPaint.textSize = context.sp(p.int(K.CLOCK_SMALL_SIZE, D.CLOCK_SMALL_SIZE).toFloat())
        smallPaint.letterSpacing = p.int(K.CLOCK_SMALL_SPACING, D.CLOCK_SMALL_SPACING) / 100f
        smallPaint.color = p.color(K.CLOCK_SMALL_COLOR, D.CLOCK_SMALL_COLOR)

        if (shadow) {
            bigPaint.setShadowLayer(context.dp(6f), 0f, context.dp(2f), 0x80000000.toInt())
            smallPaint.setShadowLayer(context.dp(3f), 0f, context.dp(1f), 0x80000000.toInt())
        } else {
            bigPaint.clearShadowLayer()
            smallPaint.clearShadowLayer()
        }
        refreshTexts()
        requestLayout()
        invalidate()
    }

    fun refreshTexts() {
        val now = Date()
        val loc = Locale.getDefault()
        day = SimpleDateFormat(if (dayFormat == "full") "EEEE" else "EEE", loc)
            .format(now).uppercase(loc).replace(".", "")
        time = SimpleDateFormat(if (use24h) "HH:mm" else "h:mm", loc).format(now)
        date = SimpleDateFormat("MMM d", loc).format(now).uppercase(loc).replace(".", "")
        requestLayout()
        invalidate()
    }

    private fun updateBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level >= 0 && scale > 0) batteryLevel = level * 100 / scale
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (isInEditMode || registered) return
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_TIME_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
        }
        val sticky = ContextCompat.registerReceiver(context, receiver, f, ContextCompat.RECEIVER_EXPORTED)
        registered = true
        if (sticky != null && sticky.action == Intent.ACTION_BATTERY_CHANGED) updateBattery(sticky)
        refreshTexts()
    }

    override fun onDetachedFromWindow() {
        if (registered) {
            try { context.unregisterReceiver(receiver) } catch (_: Exception) { }
            registered = false
        }
        super.onDetachedFromWindow()
    }

    // ---------- layout ----------

    private fun bigText(): String = day.ifEmpty { "DAY" }

    private fun extraPad(): Float = (if (shadow) context.dp(8f) else 0f) + bigPaint.strokeWidth

    private fun rowItems(): List<String> {
        val items = ArrayList<String>(3)
        if (showTime) items.add(time)
        if (showDate) items.add(date)
        if (showBattery && batteryLevel >= 0) items.add("$batteryLevel%")
        return items
    }

    private fun rowWidth(items: List<String>): Float {
        if (items.isEmpty()) return 0f
        val bigW = bigPaint.measureText(bigText())
        var sum = 0f
        for (s in items) sum += smallPaint.measureText(s)
        val minW = sum + smallPaint.textSize * 1.5f * (items.size - 1)
        return max(bigW * rowScale, minW)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val t = bigText()
        bigPaint.getTextBounds(t, 0, t.length, bounds)
        val pad = extraPad()
        val contentW = max(bigPaint.measureText(t), rowWidth(rowItems()))
        val desiredW = (paddingLeft + paddingRight + contentW + pad * 2).toInt()
        val desiredH = (paddingTop + paddingBottom + bounds.height() + pad * 2).toInt()
        setMeasuredDimension(
            resolveSize(desiredW, widthMeasureSpec),
            resolveSize(desiredH, heightMeasureSpec)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val t = bigText()
        bigPaint.getTextBounds(t, 0, t.length, bounds)
        val pad = extraPad()
        val items = rowItems()
        val bigW = bigPaint.measureText(t)
        val rowW = rowWidth(items)
        val contentW = max(bigW, rowW)

        val startX = when (align) {
            "left" -> paddingLeft + pad
            "right" -> width - paddingRight - pad - contentW
            else -> (width - contentW) / 2f
        }
        val bigX = startX + (contentW - bigW) / 2f
        val top = paddingTop + pad
        val baseline = top - bounds.top
        val textH = bounds.height().toFloat()

        if (items.isEmpty()) {
            canvas.drawText(t, bigX, baseline, bigPaint)
            return
        }

        val fm = smallPaint.fontMetrics
        val smallH = fm.descent - fm.ascent
        val gapCenter = top + textH * gapPos
        val half = smallH * gapScale / 2f

        canvas.save()
        canvas.clipOutRect(0f, gapCenter - half, width.toFloat(), gapCenter + half)
        canvas.drawText(t, bigX, baseline, bigPaint)
        canvas.restore()

        val y = gapCenter - (fm.ascent + fm.descent) / 2f
        val rowStart = startX + (contentW - rowW) / 2f
        val rowEnd = rowStart + rowW
        when (items.size) {
            1 -> drawSmall(canvas, items[0], (rowStart + rowEnd) / 2f, y, Paint.Align.CENTER)
            2 -> {
                drawSmall(canvas, items[0], rowStart, y, Paint.Align.LEFT)
                drawSmall(canvas, items[1], rowEnd, y, Paint.Align.RIGHT)
            }
            else -> {
                drawSmall(canvas, items[0], rowStart, y, Paint.Align.LEFT)
                drawSmall(canvas, items[1], (rowStart + rowEnd) / 2f, y, Paint.Align.CENTER)
                drawSmall(canvas, items[2], rowEnd, y, Paint.Align.RIGHT)
            }
        }
    }

    private fun drawSmall(canvas: Canvas, s: String, x: Float, y: Float, a: Paint.Align) {
        smallPaint.textAlign = a
        canvas.drawText(s, x, y, smallPaint)
    }
}
