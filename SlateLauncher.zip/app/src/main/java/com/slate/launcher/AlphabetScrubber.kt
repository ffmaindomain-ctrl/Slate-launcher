package com.slate.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import kotlin.math.exp
import kotlin.math.min

/** Niagara-style alphabet strip: letters bulge out in a wave under the finger. */
class AlphabetScrubber @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onScrubStart()
        fun onLetter(letter: String)
        fun onScrubEnd()
    }

    var listener: Listener? = null

    var letters: List<String> = emptyList()
        set(value) {
            if (field != value) {
                field = value
                current = -1
                invalidate()
            }
        }

    var baseColor: Int = Color.WHITE
        set(value) { field = value; invalidate() }
    var accentColor: Int = Color.WHITE
        set(value) { field = value; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val baseSize = context.sp(11f)
    private val touchStrip = context.dp(40f)
    private val maxShift = context.dp(52f)

    private var touchY = 0f
    private var active = false
    private var current = -1

    private fun step(): Float {
        if (letters.isEmpty()) return 0f
        val avail = (height - paddingTop - paddingBottom).toFloat()
        return min(avail / letters.size, baseSize * 1.9f)
    }

    private fun firstY(st: Float): Float {
        val avail = (height - paddingTop - paddingBottom).toFloat()
        return paddingTop + (avail - st * letters.size) / 2f + st / 2f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (letters.isEmpty()) return
        val st = step()
        val y0 = firstY(st)
        val cx = width - touchStrip / 2f
        val baseAlpha = Color.alpha(baseColor) / 255f
        for (i in letters.indices) {
            val cy = y0 + i * st
            var f = 0f
            if (active) {
                val d = (cy - touchY) / (st * 2.5f)
                f = exp(-(d * d))
            }
            paint.textSize = baseSize * (1f + f * 1.2f)
            if (active && i == current) {
                paint.color = accentColor
            } else {
                paint.color = baseColor
                val a = if (active) 0.6f + 0.4f * f else 0.55f
                paint.alpha = (a * baseAlpha * 255).toInt().coerceIn(0, 255)
            }
            val fm = paint.fontMetrics
            canvas.drawText(letters[i], cx - f * maxShift, cy - (fm.ascent + fm.descent) / 2f, paint)
        }
    }

    private fun update(y: Float) {
        touchY = y
        val st = step()
        if (st <= 0f) return
        val y0 = firstY(st)
        val idx = ((y - y0 + st / 2f) / st).toInt().coerceIn(0, letters.size - 1)
        if (idx != current) {
            current = idx
            listener?.onLetter(letters[idx])
            performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (letters.isEmpty() || event.x < width - touchStrip) return false
                active = true
                parent?.requestDisallowInterceptTouchEvent(true)
                listener?.onScrubStart()
                update(event.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (active) {
                    update(event.y)
                    return true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (active) {
                    active = false
                    current = -1
                    listener?.onScrubEnd()
                    invalidate()
                    return true
                }
            }
        }
        return false
    }

    val isScrubbing: Boolean get() = active
}
