package com.slate.launcher

import android.graphics.Typeface
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ListStyle(
    val homeSizeSp: Float,
    val drawerSizeSp: Float,
    val typeface: Typeface,
    val color: Int,
    val showIcons: Boolean,
    val iconPx: Int,
    val iconGapPx: Int,
    val align: String,
    val vPadPx: Int,
    val uppercase: Boolean
)

class AppAdapter(
    private val onClick: (AppEntry, View) -> Unit,
    private val onLongClick: (AppEntry) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: List<ListItem> = emptyList()
        private set
    var style: ListStyle? = null
    var drawer = false

    fun submit(newItems: List<ListItem>) {
        items = newItems
        @Suppress("NotifyDataSetChanged")
        notifyDataSetChanged()
    }

    fun headerPosition(letter: String): Int =
        items.indexOfFirst { it is ListItem.Header && it.letter == letter }

    override fun getItemCount(): Int = items.size

    override fun getItemViewType(position: Int): Int =
        if (items[position] is ListItem.Header) TYPE_HEADER else TYPE_APP

    class HeaderVH(val text: TextView) : RecyclerView.ViewHolder(text)
    class AppVH(val row: LinearLayout, val icon: ImageView, val label: TextView) : RecyclerView.ViewHolder(row)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        if (viewType == TYPE_HEADER) {
            val tv = TextView(ctx)
            tv.layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            tv.alpha = 0.55f
            tv.setPadding(0, ctx.dp(18f).toInt(), 0, ctx.dp(4f).toInt())
            return HeaderVH(tv)
        }
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        val tv = TypedValue()
        if (ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)) {
            row.setBackgroundResource(tv.resourceId)
        }
        val icon = ImageView(ctx)
        icon.scaleType = ImageView.ScaleType.FIT_CENTER
        row.addView(icon, LinearLayout.LayoutParams(ctx.dp(34f).toInt(), ctx.dp(34f).toInt()))
        val label = TextView(ctx)
        label.setSingleLine(true)
        label.ellipsize = android.text.TextUtils.TruncateAt.END
        label.setShadowLayer(ctx.dp(3f), 0f, ctx.dp(1f), 0x66000000)
        row.addView(label, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
        return AppVH(row, icon, label)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val s = style ?: return
        val dir = if (s.align == "right") View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        val hGravity = if (s.align == "center") Gravity.CENTER_HORIZONTAL else Gravity.START

        when (val item = items[position]) {
            is ListItem.Header -> {
                val h = holder as HeaderVH
                h.text.text = item.letter
                h.text.setTextColor(s.color)
                h.text.typeface = s.typeface
                h.text.layoutDirection = dir
                h.text.gravity = hGravity
            }
            is ListItem.App -> {
                val h = holder as AppVH
                val e = item.entry
                h.label.text = if (s.uppercase) e.label.uppercase() else e.label
                h.label.setTextSize(TypedValue.COMPLEX_UNIT_SP, if (drawer) s.drawerSizeSp else s.homeSizeSp)
                h.label.typeface = s.typeface
                h.label.setTextColor(s.color)

                h.icon.visibility = if (s.showIcons) View.VISIBLE else View.GONE
                if (s.showIcons) {
                    val size = if (drawer) (s.iconPx * 0.85f).toInt() else s.iconPx
                    val lp = h.icon.layoutParams as LinearLayout.LayoutParams
                    lp.width = size
                    lp.height = size
                    lp.marginEnd = s.iconGapPx
                    h.icon.layoutParams = lp
                    h.icon.setImageDrawable(e.icon)
                }
                h.row.layoutDirection = dir
                h.row.gravity = hGravity or Gravity.CENTER_VERTICAL
                h.row.setPadding(0, s.vPadPx, 0, s.vPadPx)
                h.row.setOnClickListener { v -> onClick(e, v) }
                h.row.setOnLongClickListener { onLongClick(e); true }
            }
        }
    }

    companion object {
        const val TYPE_HEADER = 0
        const val TYPE_APP = 1
    }
}
