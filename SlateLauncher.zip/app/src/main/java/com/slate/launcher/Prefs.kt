package com.slate.launcher

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Build
import android.util.TypedValue
import androidx.preference.PreferenceManager

/** Preference keys. */
object K {
    const val CLOCK_SHOW = "clock_show"
    const val CLOCK_DAY_FORMAT = "clock_day_format"
    const val CLOCK_FONT = "clock_font"
    const val CLOCK_WEIGHT = "clock_weight"
    const val CLOCK_SIZE = "clock_size"
    const val CLOCK_SPACING = "clock_spacing"
    const val CLOCK_STYLE = "clock_style"
    const val CLOCK_STROKE = "clock_stroke"
    const val CLOCK_COLOR = "clock_color"
    const val CLOCK_GAP_POS = "clock_gap_pos"
    const val CLOCK_GAP_SIZE = "clock_gap_size"
    const val CLOCK_ROW_WIDTH = "clock_row_width"
    const val CLOCK_SMALL_SIZE = "clock_small_size"
    const val CLOCK_SMALL_WEIGHT = "clock_small_weight"
    const val CLOCK_SMALL_SPACING = "clock_small_spacing"
    const val CLOCK_SMALL_COLOR = "clock_small_color"
    const val CLOCK_SHADOW = "clock_shadow"
    const val CLOCK_24H = "clock_24h"
    const val CLOCK_SHOW_TIME = "clock_show_time"
    const val CLOCK_SHOW_DATE = "clock_show_date"
    const val CLOCK_SHOW_BATTERY = "clock_show_battery"
    const val CLOCK_ALIGN = "clock_align"
    const val CLOCK_TOP = "clock_top"

    const val LIST_SIZE = "list_size"
    const val DRAWER_SIZE = "drawer_size"
    const val LIST_FONT = "list_font"
    const val LIST_WEIGHT = "list_weight"
    const val LIST_COLOR = "list_color"
    const val LIST_ICONS = "list_icons"
    const val LIST_ICON_SIZE = "list_icon_size"
    const val LIST_ALIGN = "list_align"
    const val LIST_SPACING = "list_spacing"
    const val LIST_SIDE = "list_side"
    const val LIST_UPPER = "list_upper"
    const val LIST_POSITION = "list_position"

    const val SCRUBBER_SHOW = "scrubber_show"
    const val ACCENT_COLOR = "accent_color"
    const val ICON_PACK = "icon_pack"
    const val HIDDEN = "hidden_apps"
    const val BG_COLOR = "bg_color"
    const val BG_DIM = "bg_dim"
    const val DRAWER_DIM = "drawer_dim"
    const val DRAWER_SEARCH = "drawer_search"
    const val HIDE_STATUS = "hide_status"
    const val GESTURE_UP = "gesture_up"
    const val GESTURE_DOWN = "gesture_down"
    const val GESTURE_DOUBLE = "gesture_double"

    const val FAVORITES = "favorites"
    const val LABEL_PREFIX = "label_"
}

/** Defaults. Must match android:defaultValue in res/xml/preferences.xml. */
object D {
    const val CLOCK_SHOW = true
    const val CLOCK_DAY_FORMAT = "short"
    const val CLOCK_FONT = "sans-serif"
    const val CLOCK_WEIGHT = "200"
    const val CLOCK_SIZE = 104
    const val CLOCK_SPACING = 25
    const val CLOCK_STYLE = "fill"
    const val CLOCK_STROKE = 2
    const val CLOCK_COLOR = -1 // white
    const val CLOCK_GAP_POS = 50
    const val CLOCK_GAP_SIZE = 170
    const val CLOCK_ROW_WIDTH = 150
    const val CLOCK_SMALL_SIZE = 12
    const val CLOCK_SMALL_WEIGHT = "500"
    const val CLOCK_SMALL_SPACING = 15
    const val CLOCK_SMALL_COLOR = -1
    const val CLOCK_SHADOW = false
    const val CLOCK_24H = true
    const val CLOCK_SHOW_TIME = true
    const val CLOCK_SHOW_DATE = true
    const val CLOCK_SHOW_BATTERY = true
    const val CLOCK_ALIGN = "center"
    const val CLOCK_TOP = 96

    const val LIST_SIZE = 30
    const val DRAWER_SIZE = 22
    const val LIST_FONT = "sans-serif"
    const val LIST_WEIGHT = "300"
    const val LIST_COLOR = -1
    const val LIST_ICONS = true
    const val LIST_ICON_SIZE = 34
    const val LIST_ALIGN = "left"
    const val LIST_SPACING = 10
    const val LIST_SIDE = 32
    const val LIST_UPPER = false
    const val LIST_POSITION = "center"

    const val SCRUBBER_SHOW = true
    const val ACCENT_COLOR = -1
    const val ICON_PACK = ""
    const val BG_COLOR = -16777216 // black
    const val BG_DIM = 10
    const val DRAWER_DIM = 55
    const val DRAWER_SEARCH = true
    const val HIDE_STATUS = false
    const val GESTURE_UP = "drawer"
    const val GESTURE_DOWN = "notifications"
    const val GESTURE_DOUBLE = "none"
}

class Prefs(context: Context) {
    val sp: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)

    fun int(key: String, def: Int): Int = try { sp.getInt(key, def) } catch (e: ClassCastException) { def }
    fun str(key: String, def: String): String = try { sp.getString(key, def) ?: def } catch (e: ClassCastException) { def }
    fun bool(key: String, def: Boolean): Boolean = try { sp.getBoolean(key, def) } catch (e: ClassCastException) { def }
    fun color(key: String, def: Int): Int = int(key, def)

    fun hasFavorites(): Boolean = sp.contains(K.FAVORITES)

    var favorites: List<String>
        get() = str(K.FAVORITES, "").split("|").filter { it.isNotBlank() }
        set(value) { sp.edit().putString(K.FAVORITES, value.joinToString("|")).apply() }

    val hidden: Set<String>
        get() = try { sp.getStringSet(K.HIDDEN, emptySet()) ?: emptySet() } catch (e: ClassCastException) { emptySet() }

    fun setHidden(set: Set<String>) {
        sp.edit().putStringSet(K.HIDDEN, HashSet(set)).apply()
    }

    fun label(component: String): String? = sp.getString(K.LABEL_PREFIX + component, null)

    fun setLabel(component: String, label: String?) {
        val e = sp.edit()
        if (label.isNullOrBlank()) e.remove(K.LABEL_PREFIX + component) else e.putString(K.LABEL_PREFIX + component, label)
        e.apply()
    }
}

object Fonts {
    fun make(family: String, weight: Int): Typeface {
        val base = Typeface.create(family, Typeface.NORMAL)
        if (Build.VERSION.SDK_INT >= 28) {
            return Typeface.create(base, weight.coerceIn(1, 1000), false)
        }
        if (family == "sans-serif") {
            return when {
                weight <= 150 -> Typeface.create("sans-serif-thin", Typeface.NORMAL)
                weight <= 350 -> Typeface.create("sans-serif-light", Typeface.NORMAL)
                weight <= 450 -> base
                weight <= 600 -> Typeface.create("sans-serif-medium", Typeface.NORMAL)
                else -> Typeface.create(base, Typeface.BOLD)
            }
        }
        return if (weight >= 600) Typeface.create(base, Typeface.BOLD) else base
    }
}

fun Context.dp(v: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics)

fun Context.sp(v: Float): Float =
    TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, v, resources.displayMetrics)
