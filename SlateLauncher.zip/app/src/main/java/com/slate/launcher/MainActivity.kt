package com.slate.launcher

import android.annotation.SuppressLint
import android.app.ActivityOptions
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.widget.doAfterTextChanged
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : AppCompatActivity(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var prefs: Prefs
    private lateinit var root: FrameLayout
    private lateinit var clock: SplitClockView
    private lateinit var search: EditText
    private lateinit var listFrame: FrameLayout
    private lateinit var list: RecyclerView
    private lateinit var scrubber: AlphabetScrubber
    private lateinit var bubble: TextView
    private lateinit var adapter: AppAdapter
    private lateinit var gestures: GestureDetector

    private var apps: List<AppEntry> = emptyList()
    private var drawerMode = false
    private var scrubbing = false
    private var needsReload = false
    private var needsRestyle = false

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { reload() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        prefs = Prefs(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        clock = findViewById(R.id.clock)
        search = findViewById(R.id.search)
        listFrame = findViewById(R.id.list_frame)
        list = findViewById(R.id.list)
        scrubber = findViewById(R.id.scrubber)
        bubble = findViewById(R.id.bubble)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        adapter = AppAdapter(::launch, ::showAppMenu)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        list.itemAnimator = null

        scrubber.listener = object : AlphabetScrubber.Listener {
            override fun onScrubStart() {
                scrubbing = true
                if (!drawerMode) openDrawer()
                bubble.visibility = View.VISIBLE
            }
            override fun onLetter(letter: String) {
                bubble.text = letter
                jumpTo(letter)
            }
            override fun onScrubEnd() {
                scrubbing = false
                bubble.visibility = View.GONE
            }
        }

        clock.setOnClickListener { openClockApp() }
        clock.setOnLongClickListener { openSettings(); true }
        listFrame.setOnLongClickListener { openSettings(); true }

        search.doAfterTextChanged { if (drawerMode) render() }
        search.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE) {
                val first = adapter.items.firstOrNull { it is ListItem.App } as? ListItem.App
                if (first != null) launch(first.entry, search)
                true
            } else false
        }

        gestures = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (e1 == null || scrubbing) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                if (abs(dy) < abs(dx) || abs(dy) < dp(70f)) return false
                return if (dy < 0) onSwipeUp() else onSwipeDown()
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (isOverItem(e)) return false
                return when (prefs.str(K.GESTURE_DOUBLE, D.GESTURE_DOUBLE)) {
                    "settings" -> { openSettings(); true }
                    "drawer" -> { openDrawer(); true }
                    "notifications" -> { expandNotifications(); true }
                    else -> false
                }
            }
        })
        gestures.setIsLongpressEnabled(false)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (drawerMode) closeDrawer()
            }
        })

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, f, ContextCompat.RECEIVER_EXPORTED)
        prefs.sp.registerOnSharedPreferenceChangeListener(this)

        applyStyle()
        reload()
    }

    override fun onDestroy() {
        prefs.sp.unregisterOnSharedPreferenceChangeListener(this)
        try { unregisterReceiver(packageReceiver) } catch (_: Exception) { }
        executor.shutdown()
        super.onDestroy()
    }

    override fun onResume() {
        super.onResume()
        clock.refreshTexts()
        if (needsReload) {
            needsReload = false
            needsRestyle = false
            applyStyle()
            reload()
        } else if (needsRestyle) {
            needsRestyle = false
            applyStyle()
            render()
        }
    }

    override fun onStop() {
        super.onStop()
        if (drawerMode) closeDrawer()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed while already home.
        if (drawerMode) closeDrawer() else list.smoothScrollToPosition(0)
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        if (key == null) {
            needsReload = true
            return
        }
        when {
            key == K.ICON_PACK || key.startsWith(K.LABEL_PREFIX) -> needsReload = true
            else -> needsRestyle = true
        }
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (!scrubbing) gestures.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ---------- data ----------

    private fun reload() {
        val ctx = applicationContext
        executor.execute {
            val loaded = try { AppRepository.load(ctx, prefs) } catch (e: Exception) { emptyList() }
            main.post {
                if (isDestroyed) return@post
                apps = loaded
                if (!prefs.hasFavorites() && loaded.isNotEmpty()) {
                    prefs.favorites = AppRepository.defaultFavorites(this, loaded)
                }
                render()
            }
        }
    }

    private fun visibleApps(): List<AppEntry> {
        val hidden = prefs.hidden
        return apps.filter { it.component !in hidden }
    }

    private fun render() {
        val visible = visibleApps()
        scrubber.letters = visible.map { sectionOf(it.label) }.distinct()
        val items = ArrayList<ListItem>()
        if (!drawerMode) {
            val byComp = apps.associateBy { it.component }
            for (c in prefs.favorites) byComp[c]?.let { items.add(ListItem.App(it)) }
        } else {
            val q = search.text?.toString()?.trim().orEmpty()
            if (q.isNotEmpty()) {
                visible.filter { it.label.contains(q, ignoreCase = true) }
                    .forEach { items.add(ListItem.App(it)) }
            } else {
                var last = ""
                for (a in visible) {
                    val s = sectionOf(a.label)
                    if (s != last) {
                        items.add(ListItem.Header(s))
                        last = s
                    }
                    items.add(ListItem.App(a))
                }
            }
        }
        adapter.drawer = drawerMode
        adapter.submit(items)
    }

    // ---------- style ----------

    private fun applyStyle() {
        clock.applyPrefs(prefs)
        val clp = clock.layoutParams as LinearLayout.LayoutParams
        clp.topMargin = dp(prefs.int(K.CLOCK_TOP, D.CLOCK_TOP).toFloat()).toInt()
        clock.layoutParams = clp
        updateClockVisibility()

        val color = prefs.color(K.LIST_COLOR, D.LIST_COLOR)
        val weight = prefs.str(K.LIST_WEIGHT, D.LIST_WEIGHT).toIntOrNull() ?: 300
        adapter.style = ListStyle(
            homeSizeSp = prefs.int(K.LIST_SIZE, D.LIST_SIZE).toFloat(),
            drawerSizeSp = prefs.int(K.DRAWER_SIZE, D.DRAWER_SIZE).toFloat(),
            typeface = Fonts.make(prefs.str(K.LIST_FONT, D.LIST_FONT), weight),
            color = color,
            showIcons = prefs.bool(K.LIST_ICONS, D.LIST_ICONS),
            iconPx = dp(prefs.int(K.LIST_ICON_SIZE, D.LIST_ICON_SIZE).toFloat()).toInt(),
            iconGapPx = dp(16f).toInt(),
            align = prefs.str(K.LIST_ALIGN, D.LIST_ALIGN),
            vPadPx = dp(prefs.int(K.LIST_SPACING, D.LIST_SPACING).toFloat()).toInt(),
            uppercase = prefs.bool(K.LIST_UPPER, D.LIST_UPPER)
        )

        val showScrubber = prefs.bool(K.SCRUBBER_SHOW, D.SCRUBBER_SHOW)
        scrubber.visibility = if (showScrubber) View.VISIBLE else View.GONE
        scrubber.baseColor = color
        scrubber.accentColor = prefs.color(K.ACCENT_COLOR, D.ACCENT_COLOR)

        val side = dp(prefs.int(K.LIST_SIDE, D.LIST_SIDE).toFloat()).toInt()
        val rightExtra = if (showScrubber) dp(28f).toInt() else 0
        list.setPadding(side, dp(8f).toInt(), side + rightExtra, dp(24f).toInt())
        search.setPadding(side, dp(12f).toInt(), side + rightExtra, dp(12f).toInt())
        search.setTextColor(color)
        search.setHintTextColor(ColorUtils.setAlphaComponent(color, 120))

        applyListGeometry()
        updateBackground()

        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (prefs.bool(K.HIDE_STATUS, D.HIDE_STATUS)) {
            controller.hide(WindowInsetsCompat.Type.statusBars())
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            controller.show(WindowInsetsCompat.Type.statusBars())
        }
        @Suppress("NotifyDataSetChanged")
        adapter.notifyDataSetChanged()
    }

    private fun updateBackground() {
        val bg = prefs.color(K.BG_COLOR, D.BG_COLOR)
        val dim = if (drawerMode) prefs.int(K.DRAWER_DIM, D.DRAWER_DIM) else prefs.int(K.BG_DIM, D.BG_DIM)
        root.setBackgroundColor(ColorUtils.setAlphaComponent(bg, (dim.coerceIn(0, 100) * 255) / 100))
    }

    private fun updateClockVisibility() {
        val show = prefs.bool(K.CLOCK_SHOW, D.CLOCK_SHOW) && !drawerMode
        clock.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun applyListGeometry() {
        val lp = list.layoutParams as FrameLayout.LayoutParams
        if (drawerMode) {
            lp.height = ViewGroup.LayoutParams.MATCH_PARENT
            lp.gravity = Gravity.TOP
        } else {
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            lp.gravity = when (prefs.str(K.LIST_POSITION, D.LIST_POSITION)) {
                "top" -> Gravity.TOP
                "bottom" -> Gravity.BOTTOM
                else -> Gravity.CENTER_VERTICAL
            }
        }
        list.layoutParams = lp
    }

    // ---------- drawer ----------

    private fun openDrawer() {
        if (drawerMode) return
        drawerMode = true
        updateClockVisibility()
        search.visibility = if (prefs.bool(K.DRAWER_SEARCH, D.DRAWER_SEARCH)) View.VISIBLE else View.GONE
        applyListGeometry()
        updateBackground()
        render()
        list.scrollToPosition(0)
    }

    private fun closeDrawer() {
        if (!drawerMode) return
        drawerMode = false
        hideKeyboard()
        search.setText("")
        search.clearFocus()
        search.visibility = View.GONE
        updateClockVisibility()
        applyListGeometry()
        updateBackground()
        render()
        list.scrollToPosition(0)
    }

    private fun openSearch() {
        openDrawer()
        search.visibility = View.VISIBLE
        search.requestFocus()
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
    }

    private fun jumpTo(letter: String) {
        if (!search.text.isNullOrEmpty()) search.setText("")
        val pos = adapter.headerPosition(letter)
        if (pos >= 0) (list.layoutManager as LinearLayoutManager).scrollToPositionWithOffset(pos, 0)
    }

    // ---------- gestures ----------

    private fun onSwipeUp(): Boolean {
        if (drawerMode) return false
        return when (prefs.str(K.GESTURE_UP, D.GESTURE_UP)) {
            "drawer" -> { openDrawer(); true }
            "search" -> { openSearch(); true }
            else -> false
        }
    }

    private fun onSwipeDown(): Boolean {
        if (drawerMode) {
            if (!list.canScrollVertically(-1)) {
                closeDrawer()
                return true
            }
            return false
        }
        return when (prefs.str(K.GESTURE_DOWN, D.GESTURE_DOWN)) {
            "notifications" -> { expandNotifications(); true }
            "search" -> { openSearch(); true }
            else -> false
        }
    }

    private fun isOverItem(e: MotionEvent): Boolean {
        val loc = IntArray(2)
        list.getLocationOnScreen(loc)
        return list.findChildViewUnder(e.rawX - loc[0], e.rawY - loc[1]) != null
    }

    @SuppressLint("WrongConstant")
    private fun expandNotifications() {
        try {
            val sbs = getSystemService("statusbar")
            val cls = Class.forName("android.app.StatusBarManager")
            cls.getMethod("expandNotificationsPanel").invoke(sbs)
        } catch (e: Exception) {
            // Not supported on this device.
        }
    }

    // ---------- actions ----------

    private fun launch(e: AppEntry, v: View) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(ComponentName(e.pkg, e.cls))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            val opts = ActivityOptions.makeClipRevealAnimation(v, 0, 0, v.width, v.height)
            startActivity(i, opts.toBundle())
        } catch (ex: Exception) {
            Toast.makeText(this, getString(R.string.cant_open, e.label), Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAppMenu(e: AppEntry) {
        val favs = prefs.favorites.toMutableList()
        val isFav = e.component in favs
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()

        labels.add(getString(if (isFav) R.string.remove_from_home else R.string.add_to_home))
        actions.add {
            if (isFav) favs.remove(e.component) else favs.add(e.component)
            prefs.favorites = favs
            render()
        }
        if (isFav) {
            val idx = favs.indexOf(e.component)
            if (idx > 0) {
                labels.add(getString(R.string.move_up))
                actions.add {
                    favs.removeAt(idx); favs.add(idx - 1, e.component)
                    prefs.favorites = favs; render()
                }
            }
            if (idx < favs.size - 1) {
                labels.add(getString(R.string.move_down))
                actions.add {
                    favs.removeAt(idx); favs.add(idx + 1, e.component)
                    prefs.favorites = favs; render()
                }
            }
        }
        labels.add(getString(R.string.rename))
        actions.add { renameDialog(e) }
        labels.add(getString(R.string.hide))
        actions.add {
            prefs.setHidden(prefs.hidden + e.component)
            if (isFav) { favs.remove(e.component); prefs.favorites = favs }
            render()
        }
        labels.add(getString(R.string.app_info))
        actions.add {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${e.pkg}")))
            } catch (_: Exception) { }
        }
        labels.add(getString(R.string.uninstall))
        actions.add {
            try {
                startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${e.pkg}")))
            } catch (_: Exception) { }
        }

        AlertDialog.Builder(this)
            .setTitle(e.label)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun renameDialog(e: AppEntry) {
        val input = EditText(this)
        input.setText(e.label)
        input.setSelection(input.text.length)
        val pad = dp(20f).toInt()
        val wrap = FrameLayout(this)
        wrap.setPadding(pad, pad / 2, pad, 0)
        wrap.addView(input)
        AlertDialog.Builder(this)
            .setTitle(R.string.rename)
            .setView(wrap)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                prefs.setLabel(e.component, input.text.toString().trim())
                needsReload = false
                reload()
            }
            .setNeutralButton(R.string.reset) { _, _ ->
                prefs.setLabel(e.component, null)
                needsReload = false
                reload()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun openClockApp() {
        try {
            startActivity(Intent(AlarmClock.ACTION_SHOW_ALARMS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) { }
    }
}
