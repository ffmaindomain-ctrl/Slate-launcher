package com.slate.launcher

import android.content.Context
import android.content.res.TypedArray
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.util.AttributeSet
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.preference.Preference
import androidx.preference.PreferenceViewHolder

/** Simple colour picker: swatches + hex + opacity. Stores an ARGB Int. */
class ColorPreference(context: Context, attrs: AttributeSet?) : Preference(context, attrs) {

    private var color: Int = Color.WHITE

    init {
        widgetLayoutResource = R.layout.pref_color_swatch
    }

    override fun onGetDefaultValue(a: TypedArray, index: Int): Any? {
        val s = a.getString(index) ?: return Color.WHITE
        return try { Color.parseColor(s) } catch (e: Exception) { Color.WHITE }
    }

    override fun onSetInitialValue(defaultValue: Any?) {
        color = getPersistedInt((defaultValue as? Int) ?: Color.WHITE)
        if (defaultValue is Int && sharedPreferences?.contains(key) == false) persistInt(color)
    }

    override fun onBindViewHolder(holder: PreferenceViewHolder) {
        super.onBindViewHolder(holder)
        holder.findViewById(R.id.swatch)?.background = swatch(color, context.dp(28f).toInt())
    }

    override fun onClick() {
        showDialog()
    }

    private fun setColor(c: Int) {
        if (callChangeListener(c)) {
            color = c
            persistInt(c)
            notifyChanged()
        }
    }

    private fun swatch(c: Int, size: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(c)
        setStroke(context.dp(1.5f).toInt(), 0x66FFFFFF)
        setSize(size, size)
    }

    private fun showDialog() {
        val ctx = context
        var working = color
        val pad = ctx.dp(20f).toInt()

        val layout = LinearLayout(ctx)
        layout.orientation = LinearLayout.VERTICAL
        layout.setPadding(pad, pad / 2, pad, 0)

        val preview = View(ctx)
        layout.addView(preview, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, ctx.dp(40f).toInt()))

        val hex = EditText(ctx)
        hex.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        hex.setSingleLine(true)
        val alphaLabel = TextView(ctx)
        alphaLabel.text = ctx.getString(R.string.opacity)
        val alpha = SeekBar(ctx)
        alpha.max = 255

        var updating = false
        fun refresh(updateHex: Boolean) {
            preview.background = GradientDrawable().apply {
                cornerRadius = ctx.dp(10f)
                setColor(working)
                setStroke(ctx.dp(1f).toInt(), 0x55888888)
            }
            updating = true
            if (updateHex) hex.setText(String.format("#%08X", working))
            alpha.progress = Color.alpha(working)
            updating = false
        }

        // swatch grid
        val rows = PALETTE.chunked(6)
        for (row in rows) {
            val line = LinearLayout(ctx)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER
            for (c in row) {
                val v = View(ctx)
                v.background = swatch(c, ctx.dp(32f).toInt())
                val lp = LinearLayout.LayoutParams(0, ctx.dp(36f).toInt(), 1f)
                lp.setMargins(ctx.dp(3f).toInt(), ctx.dp(6f).toInt(), ctx.dp(3f).toInt(), 0)
                v.setOnClickListener {
                    working = (c and 0x00FFFFFF) or (Color.alpha(working) shl 24)
                    refresh(true)
                }
                line.addView(v, lp)
            }
            layout.addView(line)
        }

        layout.addView(hex)
        layout.addView(alphaLabel)
        layout.addView(alpha)

        hex.setOnFocusChangeListener { _, has ->
            if (!has) {
                try { working = Color.parseColor(hex.text.toString().trim()); refresh(true) } catch (_: Exception) { }
            }
        }
        alpha.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (updating || !fromUser) return
                working = (working and 0x00FFFFFF) or (progress shl 24)
                refresh(true)
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        refresh(true)

        AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(layout)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                try { working = Color.parseColor(hex.text.toString().trim()) } catch (_: Exception) { }
                setColor(working)
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    companion object {
        private val PALETTE = intArrayOf(
            0xFFFFFFFF.toInt(), 0xFFE6E6E6.toInt(), 0xFFBDBDBD.toInt(), 0xFF8A8A8A.toInt(), 0xFF424242.toInt(), 0xFF000000.toInt(),
            0xFFFFCDD2.toInt(), 0xFFFF8A80.toInt(), 0xFFFFAB40.toInt(), 0xFFFFE57F.toInt(), 0xFFB9F6CA.toInt(), 0xFF69F0AE.toInt(),
            0xFF80D8FF.toInt(), 0xFF40C4FF.toInt(), 0xFF8C9EFF.toInt(), 0xFFB388FF.toInt(), 0xFFEA80FC.toInt(), 0xFFFF80AB.toInt()
        ).toList()
    }
}
