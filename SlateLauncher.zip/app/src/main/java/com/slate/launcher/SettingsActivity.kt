package com.slate.launcher

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.preference.ListPreference
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.PreferenceManager
import java.text.Collator
import java.util.Locale

class SettingsActivity : AppCompatActivity(), SharedPreferences.OnSharedPreferenceChangeListener {

    private lateinit var prefs: Prefs
    private lateinit var preview: SplitClockView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false)
        prefs = Prefs(this)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_settings)

        val root = findViewById<android.view.View>(R.id.settings_root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }

        preview = findViewById(R.id.preview)
        preview.applyPrefs(prefs)

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.settings_container, SettingsFragment())
                .commit()
        }
        prefs.sp.registerOnSharedPreferenceChangeListener(this)
    }

    override fun onDestroy() {
        prefs.sp.unregisterOnSharedPreferenceChangeListener(this)
        super.onDestroy()
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        preview.applyPrefs(prefs)
    }

    fun reloadSettings() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.settings_container, SettingsFragment())
            .commit()
        preview.applyPrefs(prefs)
    }
}

class SettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)
        val ctx = requireContext()

        findPreference<Preference>("set_default")?.setOnPreferenceClickListener {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
            true
        }

        findPreference<Preference>(KEY_HOME_APPS)?.setOnPreferenceClickListener {
            showHomeAppsDialog()
            true
        }
        updateHomeAppsSummary()

        findPreference<Preference>("clock_preset")?.setOnPreferenceClickListener {
            AlertDialog.Builder(ctx)
                .setTitle(R.string.pref_clock_preset)
                .setItems(Presets.names) { _, which ->
                    Presets.apply(Prefs(ctx), which)
                    (activity as? SettingsActivity)?.reloadSettings()
                }
                .show()
            true
        }

        findPreference<ListPreference>(K.ICON_PACK)?.let { lp ->
            val packs = IconPack.available(ctx)
            val names = ArrayList<CharSequence>()
            val values = ArrayList<CharSequence>()
            names.add(getString(R.string.system_icons))
            values.add("")
            for ((pkg, label) in packs) {
                names.add(label)
                values.add(pkg)
            }
            lp.setEntries(names.toTypedArray())
            lp.setEntryValues(values.toTypedArray())
            if (packs.isEmpty()) {
                lp.summaryProvider = null
                lp.summary = getString(R.string.no_icon_packs)
            }
        }

        findPreference<MultiSelectListPreference>(K.HIDDEN)?.let { mp ->
            val sorted = appChoices()
            val names = ArrayList<CharSequence>()
            val values = ArrayList<CharSequence>()
            for ((n, v) in sorted) { names.add(n); values.add(v) }
            mp.setEntries(names.toTypedArray())
            mp.setEntryValues(values.toTypedArray())
        }

        findPreference<Preference>("reset")?.setOnPreferenceClickListener {
            AlertDialog.Builder(ctx)
                .setTitle(R.string.pref_reset)
                .setMessage(R.string.reset_confirm)
                .setPositiveButton(R.string.reset) { _, _ ->
                    val sp = PreferenceManager.getDefaultSharedPreferences(ctx)
                    val edit = sp.edit()
                    for (key in sp.all.keys) {
                        if (key == K.FAVORITES || key == K.HIDDEN || key.startsWith(K.LABEL_PREFIX)) continue
                        edit.remove(key)
                    }
                    edit.commit()
                    PreferenceManager.setDefaultValues(ctx, R.xml.preferences, true)
                    (activity as? SettingsActivity)?.reloadSettings()
                }
                .setNegativeButton(android.R.string.cancel, null)
                .show()
            true
        }
    }

    override fun onResume() {
        super.onResume()
        updateHomeAppsSummary()
    }

    /** (label, component) for every launchable app, sorted by label; uses renamed labels. */
    private fun appChoices(): List<Pair<String, String>> {
        val ctx = requireContext()
        val pm = ctx.packageManager
        val prefs = Prefs(ctx)
        val entries = AppRepository.launchables(ctx).mapNotNull { ri ->
            val ai = ri.activityInfo ?: return@mapNotNull null
            val comp = "${ai.packageName}/${ai.name}"
            val label = prefs.label(comp)
                ?: try { ri.loadLabel(pm).toString() } catch (e: Exception) { ai.packageName }
            label to comp
        }.distinctBy { it.second }
        val collator = Collator.getInstance(Locale.getDefault())
        return entries.sortedWith { a, b -> collator.compare(a.first, b.first) }
    }

    private fun updateHomeAppsSummary() {
        val pref = findPreference<Preference>(KEY_HOME_APPS) ?: return
        val n = Prefs(requireContext()).favorites.size
        pref.summary = if (n == 0) getString(R.string.home_apps_none)
        else resources.getQuantityString(R.plurals.home_apps_count, n, n)
    }

    private fun showHomeAppsDialog() {
        val ctx = requireContext()
        val prefs = Prefs(ctx)
        val hidden = prefs.hidden
        val apps = appChoices().filter { it.second !in hidden }
        val current = prefs.favorites
        val names = apps.map { it.first }.toTypedArray()
        val checked = BooleanArray(apps.size) { apps[it].second in current }

        AlertDialog.Builder(ctx)
            .setTitle(R.string.pref_home_apps)
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val selected = HashSet<String>()
                for (i in apps.indices) if (checked[i]) selected.add(apps[i].second)
                // keep existing order, append newly ticked apps at the bottom
                val kept = current.filter { it in selected }
                val added = apps.map { it.second }.filter { it in selected && it !in current }
                prefs.favorites = kept + added
                updateHomeAppsSummary()
            }
            .setNeutralButton(R.string.clear_all) { _, _ ->
                prefs.favorites = emptyList()
                updateHomeAppsSummary()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    companion object {
        const val KEY_HOME_APPS = "home_apps"
    }
}

/** Clock looks taken from the four reference styles. */
object Presets {
    val names = arrayOf(
        "Classic split (white, thin)",
        "Soft relief (shadowed)",
        "Low cut (light weight)",
        "Hairline (extra thin, shadowed)",
        "Outline"
    )

    fun apply(p: Prefs, index: Int) {
        val e = p.sp.edit()
        // shared base
        e.putString(K.CLOCK_STYLE, "fill")
        e.putInt(K.CLOCK_SPACING, 25)
        e.putInt(K.CLOCK_GAP_SIZE, 170)
        e.putInt(K.CLOCK_ROW_WIDTH, 150)
        e.putInt(K.CLOCK_SMALL_SIZE, 12)
        e.putString(K.CLOCK_FONT, "sans-serif")
        when (index) {
            0 -> {
                e.putString(K.CLOCK_WEIGHT, "200")
                e.putInt(K.CLOCK_GAP_POS, 50)
                e.putInt(K.CLOCK_COLOR, -1)
                e.putInt(K.CLOCK_SMALL_COLOR, -1)
                e.putBoolean(K.CLOCK_SHADOW, false)
            }
            1 -> {
                e.putString(K.CLOCK_WEIGHT, "200")
                e.putInt(K.CLOCK_GAP_POS, 50)
                e.putInt(K.CLOCK_COLOR, 0xFFE6E6E6.toInt())
                e.putInt(K.CLOCK_SMALL_COLOR, 0xFFF2F2F2.toInt())
                e.putBoolean(K.CLOCK_SHADOW, true)
            }
            2 -> {
                e.putString(K.CLOCK_WEIGHT, "300")
                e.putInt(K.CLOCK_GAP_POS, 38)
                e.putInt(K.CLOCK_COLOR, -1)
                e.putInt(K.CLOCK_SMALL_COLOR, -1)
                e.putBoolean(K.CLOCK_SHADOW, false)
            }
            3 -> {
                e.putString(K.CLOCK_WEIGHT, "100")
                e.putInt(K.CLOCK_GAP_POS, 50)
                e.putInt(K.CLOCK_COLOR, 0xFFDADADA.toInt())
                e.putInt(K.CLOCK_SMALL_COLOR, 0xFFEEEEEE.toInt())
                e.putBoolean(K.CLOCK_SHADOW, true)
            }
            else -> {
                e.putString(K.CLOCK_STYLE, "outline")
                e.putInt(K.CLOCK_STROKE, 1)
                e.putString(K.CLOCK_WEIGHT, "400")
                e.putInt(K.CLOCK_GAP_POS, 50)
                e.putInt(K.CLOCK_COLOR, -1)
                e.putInt(K.CLOCK_SMALL_COLOR, -1)
                e.putBoolean(K.CLOCK_SHADOW, false)
            }
        }
        e.commit()
    }
}
