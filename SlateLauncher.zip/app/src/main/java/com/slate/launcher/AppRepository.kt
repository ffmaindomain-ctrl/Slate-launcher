package com.slate.launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.content.res.Resources
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.text.Collator
import java.util.Locale

class AppEntry(
    val component: String,
    val pkg: String,
    val cls: String,
    val label: String,
    val icon: Drawable?
)

sealed class ListItem {
    data class Header(val letter: String) : ListItem()
    class App(val entry: AppEntry) : ListItem()
}

fun sectionOf(label: String): String {
    val c = label.trim().firstOrNull() ?: return "#"
    return if (c.isLetter()) c.uppercaseChar().toString() else "#"
}

object AppRepository {

    private fun query(pm: PackageManager, intent: Intent): List<ResolveInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }

    private fun resolve(pm: PackageManager, intent: Intent): ResolveInfo? =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.resolveActivity(intent, PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_DEFAULT_ONLY.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
        }

    fun launchables(context: Context): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return query(context.packageManager, intent)
    }

    /** Loads every launchable app with labels and icons. Call off the main thread. */
    fun load(context: Context, prefs: Prefs): List<AppEntry> {
        val pm = context.packageManager
        val pack = IconPack.load(context, prefs.str(K.ICON_PACK, D.ICON_PACK))
        val seen = HashSet<String>()
        val out = ArrayList<AppEntry>()
        for (ri in launchables(context)) {
            val ai = ri.activityInfo ?: continue
            val comp = "${ai.packageName}/${ai.name}"
            if (!seen.add(comp)) continue
            val original = try { ri.loadLabel(pm).toString() } catch (e: Exception) { ai.packageName }
            val label = prefs.label(comp) ?: original
            val icon = pack?.getIcon(comp) ?: try { ri.loadIcon(pm) } catch (e: Exception) { null }
            out.add(AppEntry(comp, ai.packageName, ai.name, label, icon))
        }
        val collator = Collator.getInstance(Locale.getDefault())
        out.sortWith { a, b -> collator.compare(a.label, b.label) }
        return out
    }

    /** Picks phone, messages, browser, camera, gallery as first home favourites. */
    fun defaultFavorites(context: Context, apps: List<AppEntry>): List<String> {
        val pm = context.packageManager
        val intents = listOf(
            Intent(Intent.ACTION_DIAL),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING),
            Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
            Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA),
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY)
        )
        val result = ArrayList<String>()
        for (i in intents) {
            val pkg = try { resolve(pm, i)?.activityInfo?.packageName } catch (e: Exception) { null } ?: continue
            if (pkg == "android") continue
            val app = apps.firstOrNull { it.pkg == pkg } ?: continue
            if (app.component !in result) result.add(app.component)
        }
        var idx = 0
        while (result.size < 4 && idx < apps.size) {
            val c = apps[idx].component
            if (c !in result && apps[idx].pkg != context.packageName) result.add(c)
            idx++
        }
        return result
    }
}

/** ADW / Nova style icon pack reader (appfilter.xml). */
class IconPack private constructor(
    private val res: Resources,
    private val pkg: String,
    private val map: Map<String, String>
) {
    fun getIcon(component: String): Drawable? {
        val name = map[component] ?: return null
        val id = res.getIdentifier(name, "drawable", pkg)
        if (id == 0) return null
        return try { res.getDrawable(id, null) } catch (e: Exception) { null }
    }

    companion object {
        private val THEME_ACTIONS = listOf(
            "org.adw.launcher.THEMES",
            "com.novalauncher.THEME",
            "com.teslacoilsw.launcher.THEME",
            "com.gau.go.launcherex.theme"
        )

        /** Installed icon packs as (packageName, label). */
        fun available(context: Context): List<Pair<String, String>> {
            val pm = context.packageManager
            val found = LinkedHashMap<String, String>()
            for (action in THEME_ACTIONS) {
                val list = try {
                    if (Build.VERSION.SDK_INT >= 33) {
                        pm.queryIntentActivities(Intent(action), PackageManager.ResolveInfoFlags.of(0L))
                    } else {
                        @Suppress("DEPRECATION")
                        pm.queryIntentActivities(Intent(action), 0)
                    }
                } catch (e: Exception) { emptyList() }
                for (ri in list) {
                    val p = ri.activityInfo?.packageName ?: continue
                    if (!found.containsKey(p)) {
                        found[p] = try { ri.activityInfo.applicationInfo.loadLabel(pm).toString() } catch (e: Exception) { p }
                    }
                }
            }
            return found.map { it.key to it.value }.sortedBy { it.second.lowercase() }
        }

        fun load(context: Context, pkg: String): IconPack? {
            if (pkg.isBlank()) return null
            return try {
                val res = context.packageManager.getResourcesForApplication(pkg)
                val map = HashMap<String, String>()
                val id = res.getIdentifier("appfilter", "xml", pkg)
                val parser: XmlPullParser = if (id != 0) {
                    res.getXml(id)
                } else {
                    Xml.newPullParser().apply { setInput(res.assets.open("appfilter.xml"), "utf-8") }
                }
                var event = parser.eventType
                while (event != XmlPullParser.END_DOCUMENT) {
                    if (event == XmlPullParser.START_TAG && parser.name == "item") {
                        val comp = parser.getAttributeValue(null, "component")
                        val draw = parser.getAttributeValue(null, "drawable")
                        if (comp != null && draw != null) {
                            val inner = comp.substringAfter("{").substringBefore("}")
                            val slash = inner.indexOf('/')
                            if (slash > 0) {
                                val p = inner.substring(0, slash)
                                var c = inner.substring(slash + 1)
                                if (c.startsWith(".")) c = p + c
                                map["$p/$c"] = draw
                            }
                        }
                    }
                    event = parser.next()
                }
                IconPack(res, pkg, map)
            } catch (e: Exception) {
                null
            }
        }
    }
}
