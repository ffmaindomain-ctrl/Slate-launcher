# Slate Launcher

A minimal Android home screen:
- **Niagara-style** list of home apps, plus an all-apps drawer with a wave alphabet strip on the right edge.
- **Split-day clock**: big thin day name (THU) cut by a band holding time, date and battery.
- **Victoria-style customisation**: fonts, weights, sizes, colours, alignment, icon packs, gestures, hidden apps, renames, live clock preview, one-tap clock presets.

## Build the APK on GitHub (no PC tools needed)

1. In your GitHub repo: **Add file → Upload files** → upload `SlateLauncher.zip` as-is (don't unzip). Commit.
2. Make sure `.github/workflows/build.yml` exists with the contents from this zip
   (**Add file → Create new file**, or edit the existing one).
3. **Actions** tab → "Build APK" unzips the project and builds it (about 4–6 min).
4. Open the finished run → **Artifacts → SlateLauncher-apk** → download, unzip, install.

To update later, upload a new `SlateLauncher.zip` over the old one; the build reruns.

## First run
- Press the Home button and choose **Slate** → "Always", or open **Slate Settings → Set as default launcher**.
- Long-press an app → add to home / move up / move down / rename / hide / app info / uninstall.
- Long-press the clock or empty space → settings. Tap the clock → alarms.
- Swipe up → all apps. Swipe down → notifications. Touch the right edge → alphabet wave.
- Settings → Clock presets → pick one of the looks from the reference image.

Requires Android 8.0+.
