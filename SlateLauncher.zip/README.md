# Slate Launcher

A minimal Android home screen:
- **Niagara-style** list of home apps, plus an all-apps drawer with a wave alphabet strip on the right edge.
- **Split-day clock**: big thin day name (THU) cut by a band holding time, date and battery.
- **Victoria-style customisation**: fonts, weights, sizes, colours, alignment, icon packs, gestures, hidden apps, renames, live clock preview, one-tap clock presets.

## Build the APK on GitHub (no PC tools needed)

1. Create a new repository on github.com (e.g. `slate-launcher`).
2. **Add file → Upload files** and drag in everything from this folder
   (`app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradle.properties`, `README.md`). Commit.
3. The workflow lives in a hidden folder that web upload often skips. So:
   **Add file → Create new file**, name it exactly `.github/workflows/build.yml`,
   paste in the contents of `.github/workflows/build.yml` from this folder, commit.
4. Open the **Actions** tab → "Build APK" runs automatically (about 4–6 min).
5. Open the finished run → **Artifacts → SlateLauncher-apk** → download, unzip, install the APK.

## First run
- Press the Home button and choose **Slate** → "Always", or open **Slate Settings → Set as default launcher**.
- Long-press an app → add to home / move up / move down / rename / hide / app info / uninstall.
- Long-press the clock or empty space → settings. Tap the clock → alarms.
- Swipe up → all apps. Swipe down → notifications. Touch the right edge → alphabet wave.
- Settings → Clock presets → pick one of the looks from the reference image.

Requires Android 8.0+.
